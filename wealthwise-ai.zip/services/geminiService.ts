
import { GoogleGenAI, Type } from "@google/genai";
import { Transaction, Account, TransactionType, ParsedTransactionData, CategoryMap, ItemPrediction } from "../types";

/**
 * Always initialize GoogleGenAI with a named parameter using process.env.API_KEY.
 * The application must not ask the user for the key.
 */
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const parseNaturalLanguageInput = async (
  input: string,
  accounts: Account[],
  categories: CategoryMap
): Promise<ParsedTransactionData[] | null> => {
  // Create a new instance right before making an API call for fresh context
  const ai = getAI();
  const accountNames = accounts.map(a => a.name).join(", ");
  const categoryKeys = Object.keys(categories).join(", ");
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  
  const prompt = `
    You are a financial data extractor.
    Today is: ${today}.
    
    Analyze the input text and extract financial transactions.
    Input: "${input}"
    
    Context:
    - User Accounts: [${accountNames}]
    - User Categories: [${categoryKeys}]
    
    Instructions:
    1. Identify every distinct transaction.
    2. Extract 'date' strictly in "YYYY-MM-DD" format. Calculate relative dates (e.g., "yesterday") based on Today (${today}). If no date is mentioned, use ${today}.
    3. Extract description, amount (number), and type (EXPENSE/INCOME/INVESTMENT).
    4. Match 'category' from the provided list. If it doesn't fit, suggest a sensible new one.
    5. Match 'accountNameMatch' to the closest User Account name provided.
    6. Return a JSON Array.
  `;

  try {
    // Basic Text Tasks: 'gemini-3-flash-preview'
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              date: { type: Type.STRING, description: "YYYY-MM-DD" },
              description: { type: Type.STRING },
              amount: { type: Type.NUMBER },
              type: { type: Type.STRING, description: "EXPENSE, INCOME, or INVESTMENT" },
              category: { type: Type.STRING },
              subCategory: { type: Type.STRING },
              accountNameMatch: { type: Type.STRING },
              unitDetails: { type: Type.STRING },
              remarks: { type: Type.STRING },
            },
            required: ["description", "amount", "type", "category", "subCategory", "accountNameMatch"]
          }
        }
      }
    });

    if (response.text) {
      // response.text is a property, do not call as a method
      const cleanJson = response.text.trim();
      const parsed = JSON.parse(cleanJson);
      return Array.isArray(parsed) ? parsed : [parsed];
    }
    return [];
  } catch (error) {
    console.warn("Structured Output failed, retrying with standard prompt...", error);
    
    try {
        const fallbackResponse = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt + "\n\nIMPORTANT: Return strictly a valid JSON array of objects.",
            config: {
                responseMimeType: "application/json"
            }
        });
        
        if (fallbackResponse.text) {
             const cleanJson = fallbackResponse.text.trim();
             const parsed = JSON.parse(cleanJson);
             return Array.isArray(parsed) ? parsed : [parsed];
        }
    } catch (retryError) {
        console.error("Retry failed", retryError);
    }
    return null;
  }
};

export const predictItemDetails = async (
  itemName: string
): Promise<ItemPrediction | null> => {
  const ai = getAI();
  const prompt = `
    Analyze this item name: "${itemName}".
    Predict standard unit (kg, l, pcs, pack, etc), category and sub-category.
    Return valid JSON only.
  `;

  try {
     const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            unit: { type: Type.STRING },
            category: { type: Type.STRING },
            subCategory: { type: Type.STRING }
          }
        }
      }
    });
    
    if (response.text) {
      return JSON.parse(response.text) as ItemPrediction;
    }
    return null;
  } catch (e) {
    console.error("Prediction error", e);
    try {
        const fallback = await ai.models.generateContent({
            model: "gemini-3-flash-preview",
            contents: prompt + " Return JSON object with keys: unit, category, subCategory.",
             config: { responseMimeType: "application/json" }
        });
        if (fallback.text) return JSON.parse(fallback.text);
    } catch (e2) {}
    
    return null;
  }
}

export const generateMonthlyAdvice = async (
  transactions: Transaction[],
  accounts: Account[]
): Promise<string> => {
  const ai = getAI();
  
  const summary = JSON.stringify({
    totalBalance: accounts.reduce((acc, curr) => acc + curr.balance, 0),
    accounts: accounts.map(a => ({ name: a.name, balance: a.balance })),
    recentTransactions: transactions.slice(0, 50).map(t => ({
      desc: t.description,
      amt: t.amount,
      cat: t.category,
      type: t.type
    }))
  });

  const prompt = `
    You are a wealthy, wise, yet approachable financial mentor.
    Analyze this financial data (Currency: INR): ${summary}.
    
    Structure your advice in 3 distinct sections using plain text:
    1. THE SNAPSHOT (1 sentence summary)
    2. SPENDING PATTERNS (Specific analysis)
    3. ACTION PLAN (2 bullet points)
    
    Tone: Professional but encouraging.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
    });
    // response.text property directly returns the string output.
    return response.text || "Could not generate advice at this time.";
  } catch (error) {
    console.error("AI Advice Error", error);
    return "Error connecting to AI Advisor.";
  }
};
